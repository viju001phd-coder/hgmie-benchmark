# Datasets

## Included files (UCI Machine Learning Repository)

These six regression datasets are used as three-class problems (the target is split at its tertiles).
The notebooks find each file by the keyword in brackets, so the file names may vary.

| File | Dataset | Target column | Removed columns |
|---|---|---|---|
| `abalone.csv` [abalone] | Abalone (UCI id 1) | `Rings` | `Sex` |
| `AirfoilSelfNoise.csv` [airfoil] | Airfoil Self-Noise (UCI id 291) | `SSPL` | — |
| `auto-mpg.csv` [auto-mpg] | Auto MPG (UCI id 9) | `mpg` | `car name`; 6 rows with missing horsepower dropped |
| `Concrete Compressive Strength.csv` [concrete] | Concrete Compressive Strength (UCI id 165) | `strength` | derived columns (`water_cement_ratio`, `total_binder`, `aggregate_to_cement`, `cement_water_interaction`, `age_strength_proxy`) |
| `ENB2012_data.csv` [enb2012] | Energy Efficiency (UCI id 242) | `Y1` (heating load) | `Y2` (cooling load) |
| `power_plant.csv` [power_plant] | Combined Cycle Power Plant (UCI id 294) | `PE` | — |

UCI datasets are distributed under the CC BY 4.0 license; please cite the UCI Machine Learning Repository
(Dua and Graff, 2019) and the original dataset donors when using them.

## Downloaded automatically

- **scikit-learn:** Wine, Breast Cancer Wisconsin (Diagnostic).
- **OpenML** (via `sklearn.datasets.fetch_openml`, version 1): glass, ionosphere, vehicle,
  banknote-authentication, segment, spambase, page-blocks, optdigits, satimage, MagicTelescope, letter.
- **OpenML, naturally incomplete:** diabetes (Pima), titanic, hepatitis, colic (Horse colic), credit-approval.

Preprocessing (constant columns, rare classes, subsampling to 3,000 rows, recoding of Pima zeros,
removal of Titanic identifier and leakage columns) is done inside the notebooks.
