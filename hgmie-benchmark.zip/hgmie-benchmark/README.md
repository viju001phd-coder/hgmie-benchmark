# HG-MIE: Prediction-Aware Weighting of Heterogeneous Imputation Generators

Code and results for the paper *"HG-MIE: Prediction-Aware Weighting of Heterogeneous Imputation Generators
for Classification With Missing Data"* (submitted to IEEE Access).

HG-MIE combines four imputation generators (mean imputation, Bayesian-ridge chained equations, Extra-Trees
with predictive mean matching, and nearest-neighbour hot-deck), pools several stochastic draws within each
generator, and learns one weight per generator by minimizing the cross-fitted log-loss of the downstream
random forest. It is evaluated against 15 alternatives on 19 datasets with simulated missingness and 5 datasets
with natural missingness.

## Repository contents

| Folder | Contents |
|---|---|
| `notebooks/` | The three Jupyter notebooks that produced the results (see "How the results were produced") |
| `results/` | Raw per-replicate results (`raw/`) and the final tables (`tables/`) of each run |
| `data/` | The six UCI dataset files and a description of all datasets |

The tables reported in the paper are in `results/results_full_final/tables/`.

## Requirements

- Python 3.8 (the experiments used 3.8.10)
- `pip install -r requirements.txt`

The experiments used scikit-learn 1.3.2. In this version `IterativeImputer(keep_empty_features=True)` performs
no iterations and returns mean imputation; the repair and final notebooks avoid this (class `SafeIterative`)
and run a self-test before every experiment.

## How the results were produced

The final results combine three runs. All runs use identical seeded train/test splits and missingness masks,
so results of methods that do not depend on the HG-MIE configuration could be computed once and re-used.

1. **First full run** (`HG_MIE_worker_local.ipynb` → `results/results_full/`). Its results for HyperImpute,
   tuned HistGB, Mean + RF and Mean + indicator + RF are used in the paper. Its iterative imputers were affected
   by the scikit-learn issue above, so its other results are not used.
2. **Repair run** (`HG_MIE_repair_run_local.ipynb` → `results/results_full_repair/`). Provides MICE (BR) + RF and
   the MissForest-style baseline.
3. **Final run** (`HG_MIE_final_run_local.ipynb` → `results/results_full_final/`). Runs HG-MIE with the final
   generators {Mean, BR, ET, KNN}, compute-matched MIE, the small-sample study, the draws study and the conformal
   analysis, and merges the re-used results into the final tables.

## How to reproduce

1. Create a working folder, for example `~/hgmie_project`, and copy the CSV files from `data/` into
   `~/hgmie_project/data/`.
2. Each notebook can be split across several workers: make copies, set `WORKER_ID = 1, 2, ...` and the same
   `N_WORKERS` in Cell 2 of every copy, then run all cells in each copy. Each worker uses an equal share of the
   CPU cores. Runs are resumable: after an interruption, run all cells again.
3. Run the three notebooks in the order above. When all workers of the final run have finished, run its last two
   cells (progress and tables) in one copy; the tables are written to `~/hgmie_project/results_full_final/tables/`.

To only inspect or re-analyse the reported results, use the CSV files in `results/`; no computation is needed.

## Citation

Please cite the paper if you use this code (citation details will be added after publication).

## License

Code: MIT (see `LICENSE`). Datasets: see `data/README.md`.
